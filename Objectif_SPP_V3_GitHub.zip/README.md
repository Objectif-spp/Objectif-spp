# Objectif SPP V3 — dossier GitHub prêt

## Mise en ligne
1. Crée un dépôt GitHub public, par exemple `objectif-spp`.
2. Envoie **tout le contenu de ce dossier** à la racine du dépôt.
3. Vérifie que `index.html` est directement à la racine.
4. GitHub → Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.
5. L'adresse sera de la forme `https://TONPSEUDO.github.io/objectif-spp/`.

## Contenu V3
- accueil responsive
- cours
- bibliothèque GDO/GTO avec liens officiels
- recherche documentaire
- 30 QCM
- catégories
- examen blanc de 10 questions avec chronomètre
- correction et score
- statistiques locales
- préparation Caporal, Sergent, Lieutenant, Capitaine, Colonel
- calendrier officiel
- préparation physique / Luc Léger
- aucun framework ni dépendance : le site fonctionne avec un simple `index.html`

## Important
Les pages officielles sont liées pour éviter d'embarquer des PDF qui peuvent devenir obsolètes. Le site est pédagogique et ne remplace pas la formation, les consignes locales ou les textes officiels.
